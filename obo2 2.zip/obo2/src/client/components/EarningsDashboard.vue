<!-- OnlyFans Automation Manager
     File: EarningsDashboard.vue
     Purpose: earnings widgets container
     Created: 2025-07-16 – v1.0 -->
<template>
  <div class="grid gap-4 p-4 md:grid-cols-2 lg:grid-cols-3">
    <PayoutPulse />
    <!-- more earnings cards soon -->
  </div>
</template>

<script setup>
import PayoutPulse from './PayoutPulse.vue'
</script>

<!-- End of File – Last modified 2025-07-16 -->
