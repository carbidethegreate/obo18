<!-- OnlyFans Automation Manager
     File: MessagingDashboard.vue
     Purpose: shell for DMs inbox / composer
     Created: 2025-07-16 – v1.0 -->
<template>
  <div class="p-4">
    <h2 class="text-xl font-semibold mb-4">Messages</h2>

    <!-- stub content -->
    <p class="text-slate-500">
      Inbox coming soon …
    </p>
  </div>
</template>

<script setup>
/* empty for now */
</script>

<!-- End of File – Last modified 2025-07-16 -->
