<template><AnalyticsDashboard /></template>
<script setup>
import AnalyticsDashboard from '../components/AnalyticsDashboard.vue'
</script>
