<template><ContentDashboard /></template>
<script setup>
import ContentDashboard from '../components/ContentDashboard.vue'
</script>
