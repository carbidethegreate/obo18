<template><EarningsDashboard /></template>
<script setup>
import EarningsDashboard from '../components/EarningsDashboard.vue'
</script>
