<template><MessagingDashboard /></template>
<script setup>
import MessagingDashboard from '../components/MessagingDashboard.vue'
</script>
