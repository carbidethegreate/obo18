<template><SettingsDashboard /></template>
<script setup>
import SettingsDashboard from '../components/SettingsDashboard.vue'
</script>
