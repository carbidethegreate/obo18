<template><SyncDashboard /></template>
<script setup>
import SyncDashboard from '../components/SyncDashboard.vue'
</script>
