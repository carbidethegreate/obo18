/*  OnlyFans Automation Manager
    File: run.js
    Purpose: project metadata export for test configuration
    Created: 2025-07-06 – v1.0
*/

export default {
  name: 'obo2',
  description: 'OnlyFans Automation Manager tests',
  version: '1.0.0'
};

/*  End of File – Last modified 2025-07-06 */